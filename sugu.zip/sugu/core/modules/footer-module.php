
<?php

#Contenido php de la cabecera del sitio web

?>
	</body>
</html>