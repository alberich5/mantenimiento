<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="shortcut icon" href="<?php echo RES;?>logo/logo.png">
	<link rel="stylesheet" href="<?php echo RES;?>css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo RES;?>css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo RES;?>css/AdminLTE.min.css">
	<link rel="stylesheet" href="<?php echo RES;?>css/skins/_all-skins.min.css">
	<link rel="stylesheet" href="<?php echo RES;?>datatables/jquery.dataTables.min.css">
	<script src="<?php echo RES;?>js/jquery.min.js"></script>
	<script src="<?php echo RES;?>js/bootstrap.min.js"></script>
	<script src="<?php echo RES;?>js/app.min.js"></script>
	<script src="<?php echo RES;?>datatables/jquery.dataTables.min.js"></script>
	<script>
	$(document).ready(function(){
		$('#table').DataTable();
	});
	</script>
<?php

#Contenido php de la cabecera del sitio web

?>
	<title>Sugerencias Pabic</title>