<?php
#Archivo en el que guardamos todas las variables (22/10/2016)

#Definimos la url del sitio web
$site_url='http://localhost/sugu/';
define("URL", $site_url, true);

#Definimos la carpeta de los ESTILOS Y ACCESORIOS
$site_res='res/';
define("RES", $site_url.$site_res, true);

#Definimos la carpeta de los ARCHIVOS SUBIDOS
$site_data='data/';
define("DATA", $site_url.$site_data, true);

#Variables definidas para el sitio web
/*/
	[...code...]
/*/

#Titulo de la web
define("TITLEPAGE", "Sugux LITE v.1.0.", true);

?>