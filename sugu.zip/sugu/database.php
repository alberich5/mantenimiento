<?php
// Created by dacoto.es
// Conexión a la base de datos creada el 22-02-2017
// Creación de las variables de la base de datos
$host_db="localhost";
$user_db="root";
$pass_db="";
$tabl_db="pabicoax_sugerencias";

#Definimos las constantes de los datos de la bariable y evitamos que de errror
define("HOST", $host_db, true);
define("USER", $user_db, true);
define("PASS", $pass_db, true);
define("TABL", $tabl_db, true);

?>